const express = require('express')
const mongoose=require('mongoose')
const Product = require('./models/productModel')
const Review = require('./models/reviewmodel')
const router = require('./routes/productRoutes')
const router1 = require('./routes/reviewRoutes')
const DB = require('./Middleware/db')
DB.connectToDB()

const app = express()
app.use(express.json())
app.use(express.urlencoded({extended: false}))

app.use('/',router)
app.use('/',router1)

app.get('/',(req,res) => {
    res.send('Hello NODE API, My name is Manan Vashisht, 2110990838.')
} )

app.listen(3000,()=> {
                console.log('Node API app is running on port 3000 ')
             })

