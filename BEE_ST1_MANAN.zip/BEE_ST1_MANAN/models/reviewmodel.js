const mongoose= require('mongoose')

const reviewSchema = mongoose.Schema(
    {
        content:{
            type: String,
            required: [true, "Please enter a product name"]
        },
        rating: {
            type: Number,
            required :true,
            default: 0,
        },
        author: {
            type: String,
            required: true,

        },
        createdAt: {
            type: String,
            required: false,
        }
    },
    {
        timestamps: true,
    }
)

const Review =mongoose.model('Review', reviewSchema);

module.exports = Review;