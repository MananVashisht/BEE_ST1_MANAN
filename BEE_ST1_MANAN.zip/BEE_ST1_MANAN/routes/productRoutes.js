const express=require('express')
const router=express.Router()
const Product = require('../models/productModel');
const dataController= require('../Controller/dataController')

router.get('/products', dataController.getAllProducts);
router.get('/products/:id', dataController.getProductById);
router.post('/products', dataController.createProduct);
router.put('/products/:id', dataController.updateProduct);
router.delete('/products/:id', dataController.deleteProduct);

module.exports = router