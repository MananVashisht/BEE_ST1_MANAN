const express=require('express')
const router1=express.Router()
const Review = require('../models/reviewmodel');
const dataController= require('../Controller/reviewController')

router1.get('/review', dataController.getAllProducts);
router1.get('/review/:id', dataController.getProductById);
router1.post('/review', dataController.createProduct);
router1.put('/review/:id', dataController.updateProduct);
router1.delete('/review/:id', dataController.deleteProduct);

module.exports = router1